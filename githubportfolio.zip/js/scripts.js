// Empty JS for your own code to be here
let darkMode = () => {
    let element = document.querySelector('body');
    element.classList.toggle("dark-mode");
}